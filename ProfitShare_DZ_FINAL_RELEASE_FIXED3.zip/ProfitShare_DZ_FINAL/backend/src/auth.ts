import { Body, Controller, Get, Injectable, Post, Req, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { IsEmail, IsOptional, IsString, MinLength } from 'class-validator';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from './prisma.service';

class RegisterDto { @IsString() fullName!:string; @IsString() phone!:string; @IsOptional() @IsEmail() email?:string; @IsString() @MinLength(8) password!:string; }
class LoginDto { @IsString() phone!:string; @IsString() password!:string; }

@Injectable() export class AuthService {
  constructor(private prisma:PrismaService, private jwt:JwtService) {}
  async register(d:RegisterDto){
    const exists=await this.prisma.user.findFirst({where:{OR:[{phone:d.phone},{email:d.email??undefined}]}});
    if(exists) throw new UnauthorizedException('الحساب موجود مسبقاً');
    const user=await this.prisma.$transaction(async tx=>{
      const u=await tx.user.create({data:{fullName:d.fullName,phone:d.phone,email:d.email,passwordHash:await bcrypt.hash(d.password,12),status:'ACTIVE'}});
      await tx.kycProfile.create({data:{userId:u.id}});
      await tx.ledgerAccount.create({data:{accountCode:`WALLET:${u.id}`,name:`Wallet ${u.fullName}`,accountType:'LIABILITY',userId:u.id}});
      return u;
    });
    return this.issue(user);
  }
  async login(d:LoginDto){const u=await this.prisma.user.findUnique({where:{phone:d.phone}}); if(!u || !(await bcrypt.compare(d.password,u.passwordHash))) throw new UnauthorizedException('بيانات الدخول غير صحيحة'); if(u.status==='BLOCKED'||u.status==='CLOSED') throw new UnauthorizedException('الحساب غير متاح'); return this.issue(u);}
  verifyToken(token:string){return this.jwt.verify(token);}  
  issue(u:any){return {accessToken:this.jwt.sign({sub:u.id,role:u.role}),user:{id:u.id,fullName:u.fullName,phone:u.phone,email:u.email,role:u.role,status:u.status}};}
  async me(id:string){return this.prisma.user.findUniqueOrThrow({where:{id},select:{id:true,fullName:true,phone:true,email:true,role:true,status:true,phoneVerified:true,kyc:true,bankAccounts:{select:{id:true,bankName:true,ibanLast4:true,status:true}}}})}
}
@Controller('auth') export class AuthController {
 constructor(private auth:AuthService){}
 @Post('register') register(@Body() d:RegisterDto){return this.auth.register(d)}
 @Post('login') login(@Body() d:LoginDto){return this.auth.login(d)}
 @Get('me') me(@Req() req:any){const id=this.userId(req);return this.auth.me(id)}
 userId(req:any){const h=req.headers?.authorization||''; if(!h.startsWith('Bearer ')) throw new UnauthorizedException('Authentication required'); try{return this.auth.verifyToken(h.slice(7)).sub}catch{throw new UnauthorizedException('Invalid token')}}
}
