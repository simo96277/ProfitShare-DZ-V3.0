import { Body, Controller, Get, Param, Post, Req, UnauthorizedException } from '@nestjs/common';
import { IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { PrismaService } from './prisma.service';
import { JwtService } from '@nestjs/jwt';
class CreateProjectDto { @IsString() title!:string; @IsString() description!:string; @IsNumber() @Min(0) targetAmount!:number; @IsNumber() @Min(0) minimumInvestment!:number; @IsOptional() @IsNumber() @Min(0) maximumInvestment?:number; }
@Controller('projects') export class ProjectsController { constructor(private prisma:PrismaService,private jwt:JwtService){}
 @Get() list(){return this.prisma.project.findMany({where:{status:{in:['OPEN','FUNDED','ACTIVE']}},orderBy:{createdAt:'desc'},select:{id:true,title:true,description:true,targetAmount:true,minimumInvestment:true,maximumInvestment:true,currency:true,status:true,riskLevel:true,createdAt:true}})}
 @Get(':id') get(@Param('id') id:string){return this.prisma.project.findUniqueOrThrow({where:{id},include:{documents:true}})}
 @Post() create(@Req() req:any,@Body() d:CreateProjectDto){const h=req.headers?.authorization||'';if(!h.startsWith('Bearer '))throw new UnauthorizedException();const p=this.jwt.verify(h.slice(7));if(p.role!=='ADMIN')throw new UnauthorizedException();const slug=d.title.toLowerCase().trim().replace(/[^a-z0-9\u0600-\u06ff]+/g,'-').replace(/^-|-$/g,'');return this.prisma.project.create({data:{title:d.title,slug:`${slug}-${Date.now()}`,description:d.description,targetAmount:d.targetAmount,minimumInvestment:d.minimumInvestment,maximumInvestment:d.maximumInvestment,currency:'DZD',status:'OPEN'}})} }
