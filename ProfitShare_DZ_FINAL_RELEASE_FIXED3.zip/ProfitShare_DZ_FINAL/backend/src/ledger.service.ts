import { BadRequestException, Injectable } from '@nestjs/common';
import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaService } from './prisma.service';

type Line = { ledgerAccountId: string; debit: string; credit: string };

@Injectable()
export class LedgerService {
  constructor(private readonly prisma: PrismaService) {}
  async createJournalEntry(input: { entryNumber:string; entryType:string; referenceType?:string; referenceId?:string; description?:string; lines:Line[] }, client?: PrismaClient | Prisma.TransactionClient) {
    const tx: any = client ?? this.prisma;
    const debit = input.lines.reduce((s,x)=>s.plus(new Prisma.Decimal(x.debit)), new Prisma.Decimal(0));
    const credit = input.lines.reduce((s,x)=>s.plus(new Prisma.Decimal(x.credit)), new Prisma.Decimal(0));
    if (!debit.eq(credit)) throw new BadRequestException('Ledger entry غير متوازن');
    return tx.journalEntry.create({data:{entryNumber:input.entryNumber,entryType:input.entryType,referenceType:input.referenceType,referenceId:input.referenceId,description:input.description,status:'POSTED',lines:{create:input.lines.map(x=>({ledgerAccountId:x.ledgerAccountId,debit:x.debit,credit:x.credit}))}},include:{lines:true}});
  }
  async balance(accountId:string){
    const r=await this.prisma.journalLine.aggregate({where:{ledgerAccountId:accountId},_sum:{debit:true,credit:true}});
    return new Prisma.Decimal(r._sum.credit??0).minus(new Prisma.Decimal(r._sum.debit??0));
  }
}
