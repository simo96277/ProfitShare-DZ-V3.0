import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from './prisma.service';
import { LedgerService } from './ledger.service';
import { HealthController } from './health.controller';
import { ProjectsController } from './projects.controller';
import { InvestmentsController } from './investments.controller';
import { FinanceController } from './finance.controller';
import { AuthController, AuthService } from './auth';
import { KycController } from './kyc.controller';
import { AdminController } from './admin.controller';
@Module({imports:[JwtModule.register({secret:process.env.JWT_SECRET||'CHANGE_ME_IN_PRODUCTION',signOptions:{expiresIn:'7d'}})],controllers:[HealthController,ProjectsController,InvestmentsController,FinanceController,AuthController,KycController,AdminController],providers:[PrismaService,LedgerService,AuthService]}) export class AppModule {}
