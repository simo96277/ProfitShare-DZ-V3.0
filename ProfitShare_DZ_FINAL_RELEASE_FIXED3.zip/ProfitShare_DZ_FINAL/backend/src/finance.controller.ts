import { BadRequestException, Body, Controller, Get, Param, Post, Req, UnauthorizedException } from '@nestjs/common';
import { IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { Prisma } from '@prisma/client';
import { PrismaService } from './prisma.service';
import { LedgerService } from './ledger.service';
import { AuthService } from './auth';
class DepositDto { @IsNumber() @Min(1) amount!:number; @IsOptional() @IsString() reference?:string; }
class BankDto { @IsString() accountHolderName!:string; @IsString() bankName!:string; @IsString() iban!:string; }
class WithdrawDto { @IsString() bankAccountId!:string; @IsNumber() @Min(1) amount!:number; }
@Controller('wallet') export class FinanceController {
 constructor(private prisma:PrismaService, private ledger:LedgerService, private auth:AuthService){}
 uid(req:any){const h=req.headers?.authorization||'';if(!h.startsWith('Bearer '))throw new UnauthorizedException('Authentication required');return this.auth.verifyToken(h.slice(7)).sub;}
 @Get('balance') async balance(@Req() req:any){const id=this.uid(req);const a=await this.prisma.ledgerAccount.findUniqueOrThrow({where:{accountCode:`WALLET:${id}`}});const b=await this.ledger.balance(a.id);return {balance:b.toFixed(2),currency:'DZD'};}
 @Get('transactions') async tx(@Req() req:any){const id=this.uid(req);const a=await this.prisma.ledgerAccount.findUniqueOrThrow({where:{accountCode:`WALLET:${id}`}});return this.prisma.journalLine.findMany({where:{ledgerAccountId:a.id},orderBy:{createdAt:'desc'},include:{journalEntry:true}});}
 @Post('deposit') async deposit(@Req() req:any,@Body() d:DepositDto){const id=this.uid(req);const key=`DEP:${id}:${Date.now()}`;return this.prisma.paymentTransaction.create({data:{userId:id,provider:'BANK_TRANSFER_MANUAL',providerReference:d.reference,type:'DEPOSIT',amount:d.amount,currency:'DZD',status:'PENDING',idempotencyKey:key}});}
 @Post('bank-accounts') async bank(@Req() req:any,@Body() d:BankDto){const id=this.uid(req);return this.prisma.bankAccount.create({data:{userId:id,accountHolderName:d.accountHolderName,bankName:d.bankName,ibanEncrypted:d.iban,ibanLast4:d.iban.slice(-4),status:'PENDING'}});}
 @Get('bank-accounts') async banks(@Req() req:any){return this.prisma.bankAccount.findMany({where:{userId:this.uid(req)},select:{id:true,accountHolderName:true,bankName:true,ibanLast4:true,status:true}})}
 @Post('withdraw') async withdraw(@Req() req:any,@Body() d:WithdrawDto){const id=this.uid(req);const ba=await this.prisma.bankAccount.findFirst({where:{id:d.bankAccountId,userId:id,status:'VERIFIED'}});if(!ba)throw new BadRequestException('الحساب البنكي غير موثق');const acc=await this.prisma.ledgerAccount.findUniqueOrThrow({where:{accountCode:`WALLET:${id}`}});const bal=await this.ledger.balance(acc.id);if(bal.lt(new Prisma.Decimal(d.amount)))throw new BadRequestException('الرصيد غير كاف');return this.prisma.withdrawal.create({data:{withdrawalNumber:`WR-${Date.now()}`,userId:id,bankAccountId:ba.id,amount:d.amount,netAmount:d.amount,status:'REQUESTED',currency:'DZD'}})}
}
