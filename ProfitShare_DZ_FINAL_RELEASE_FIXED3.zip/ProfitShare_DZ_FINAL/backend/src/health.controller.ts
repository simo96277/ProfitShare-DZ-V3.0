import { Controller, Get } from '@nestjs/common';
@Controller('health') export class HealthController { @Get() getHealth(){return {ok:true,service:'profitshare-dz-backend',version:'3.0.0',environment:process.env.NODE_ENV||'production'}} }
