import { Body, Controller, Get, Post, Req, UnauthorizedException } from '@nestjs/common';
import { IsOptional, IsString } from 'class-validator';
import { PrismaService } from './prisma.service';
import { JwtService } from '@nestjs/jwt';
class KycDto { @IsOptional() @IsString() nationality?:string; @IsOptional() @IsString() documentType?:string; @IsOptional() @IsString() documentNumber?:string; @IsOptional() @IsString() address?:string; }
@Controller('kyc') export class KycController { constructor(private prisma:PrismaService,private jwt:JwtService){} uid(req:any){const h=req.headers?.authorization||'';if(!h.startsWith('Bearer '))throw new UnauthorizedException();return this.jwt.verify(h.slice(7)).sub;}
 @Get() get(@Req() req:any){return this.prisma.kycProfile.findUnique({where:{userId:this.uid(req)},include:{documents:true}})}
 @Post() save(@Req() req:any,@Body() d:KycDto){const id=this.uid(req);return this.prisma.kycProfile.upsert({where:{userId:id},create:{userId:id,nationality:d.nationality,documentType:d.documentType,documentNumberHash:d.documentNumber,address:d.address,status:'PENDING'},update:{nationality:d.nationality,documentType:d.documentType,documentNumberHash:d.documentNumber,address:d.address,status:'PENDING'}})} }
