# ProfitShare DZ 3.0 — Release Candidate

Flutter mobile app + NestJS + PostgreSQL/Prisma.

## Included
- Account registration/login with JWT.
- Multilingual UI: Arabic, French, English.
- KYC profile workflow.
- Bank account management.
- Wallet balance from double-entry ledger.
- Deposit request (manual bank transfer workflow) + admin confirmation.
- Withdrawal request + admin completion.
- Projects and authenticated investments using wallet balance.
- Decimal accounting and idempotent payment records.
- Admin dashboard APIs.
- GitHub Actions APK build.

## Important before real-money launch
This repository is a technical release candidate. It does not by itself make ProfitShare DZ legally authorized to solicit public investment or operate payment services. In Algeria, crowdfunding investment activity is regulated by COSOB and payment services are regulated by the Bank of Algeria. Obtain the required approvals/agreements and connect an authorized payment provider before accepting public funds.

## Backend
Set DATABASE_URL and JWT_SECRET. Run `npm install`, `npx prisma generate`, `npx prisma migrate deploy`, then `npm run build`.

## Mobile
Build with:
flutter build apk --release --dart-define=API_URL=https://YOUR-API-DOMAIN/api

For Android emulator use http://10.0.2.2:3000/api.

## Admin account
The Prisma seed creates one ADMIN account from environment variables:
- `ADMIN_PHONE` (default only for local testing: `0550000000`)
- `ADMIN_PASSWORD` (default only for local testing: `ChangeMe123!`)

For any real deployment, set strong unique values before running `npm run seed` and do not use the defaults.

## Local backend setup
```bash
cd backend
cp .env.example .env
# Edit DATABASE_URL and JWT_SECRET, and set ADMIN_PHONE / ADMIN_PASSWORD
npm install
npx prisma generate
npx prisma migrate deploy
npm run seed
npm run build
npm start
```

## Production checklist
1. PostgreSQL with backups and encryption at rest.
2. HTTPS/TLS and a real API domain.
3. Strong JWT secret stored in deployment secrets.
4. Admin credentials stored in secrets, never committed to Git.
5. KYC/document storage with access controls and retention policy.
6. Real payment/escrow/custody integration only through an appropriately authorized provider.
7. Independent legal/compliance review before accepting public investment funds.
8. Client-money segregation and a complete immutable audit trail.
9. Decimal-safe ledger and reconciliation against the payment/bank provider.
10. Monitoring, rate limiting, 2FA for admins, backups and incident recovery.
